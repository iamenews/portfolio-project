    // Function to increment the counter
    function incrementCounter() {
      var counterElement = document.getElementById('counterValue');
      var count = parseInt(counterElement.innerText);
      counterElement.innerText = count + 1;
    }

    // Increment the counter when the page loads
    window.onload = incrementCounter;